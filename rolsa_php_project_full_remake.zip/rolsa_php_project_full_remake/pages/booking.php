<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service = $_POST['service'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $userId = $_SESSION['user_id'];
    $stmt = $conn->prepare("INSERT INTO bookings (user_id, service_type, booking_date, booking_time) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $userId, $service, $date, $time);
    $stmt->execute();
    echo "Booking confirmed.";
}
?>
<form method="POST">
  <select name="service">
    <option value="consultation">Consultation</option>
    <option value="installation">Installation</option>
  </select>
  <input type="date" name="date" required>
  <input type="time" name="time" required>
  <button type="submit">Book Now</button>
</form>