<?php
session_start();
require_once '../config/db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $electricity = $_POST['electricity'];
    $gas = $_POST['gas'];
    $mileage = $_POST['mileage'];
    $vehicle = $_POST['vehicle'];
    $userId = $_SESSION['user_id'];
    $vehicleFactor = match($vehicle) {
        'petrol' => 0.411,
        'diesel' => 0.471,
        'hybrid' => 0.2,
        'ev' => 0.1,
        default => 0
    };
    $total = $electricity * 0.233 + $gas * 0.184 + $mileage * $vehicleFactor;
    $stmt = $conn->prepare("INSERT INTO carbon_logs (user_id, electricity, gas, mileage, vehicle_type, total_emissions) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("idddsd", $userId, $electricity, $gas, $mileage, $vehicle, $total);
    $stmt->execute();
    echo "Your monthly footprint is: " . round($total, 2) . " kg CO2e";
}
?>
<form method="POST">
  <input type="number" name="electricity" required placeholder="Electricity (kWh)">
  <input type="number" name="gas" required placeholder="Gas (kWh)">
  <input type="number" name="mileage" required placeholder="Miles driven">
  <select name="vehicle">
    <option value="none">None</option>
    <option value="petrol">Petrol</option>
    <option value="diesel">Diesel</option>
    <option value="ev">Electric Vehicle</option>
    <option value="hybrid">Hybrid</option>
  </select>
  <button type="submit">Calculate</button>
</form>