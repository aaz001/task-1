<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$userId = $_SESSION['user_id'];
$booking_query = $conn->prepare("SELECT service_type, booking_date, booking_time, status FROM bookings WHERE user_id = ?");
$booking_query->bind_param("i", $userId);
$booking_query->execute();
$booking_result = $booking_query->get_result();
$carbon_query = $conn->prepare("SELECT electricity, gas, mileage, vehicle_type, total_emissions, created_at FROM carbon_logs WHERE user_id = ?");
$carbon_query->bind_param("i", $userId);
$carbon_query->execute();
$carbon_result = $carbon_query->get_result();
?>
<h2>My Bookings</h2>
<table border="1">
  <tr><th>Service</th><th>Date</th><th>Time</th><th>Status</th></tr>
  <?php while ($row = $booking_result->fetch_assoc()): ?>
    <tr>
      <td><?= $row['service_type'] ?></td>
      <td><?= $row['booking_date'] ?></td>
      <td><?= $row['booking_time'] ?></td>
      <td><?= $row['status'] ?></td>
    </tr>
  <?php endwhile; ?>
</table>
<h2>My Carbon Footprint History</h2>
<table border="1">
  <tr><th>Date</th><th>Electricity</th><th>Gas</th><th>Mileage</th><th>Vehicle</th><th>CO2e</th></tr>
  <?php while ($log = $carbon_result->fetch_assoc()): ?>
    <tr>
      <td><?= $log['created_at'] ?></td>
      <td><?= $log['electricity'] ?></td>
      <td><?= $log['gas'] ?></td>
      <td><?= $log['mileage'] ?></td>
      <td><?= $log['vehicle_type'] ?></td>
      <td><?= round($log['total_emissions'], 2) ?></td>
    </tr>
  <?php endwhile; ?>
</table>